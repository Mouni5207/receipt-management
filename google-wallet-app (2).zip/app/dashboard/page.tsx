"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CreditCard,
  Upload,
  BarChart3,
  Gift,
  Bell,
  MapPin,
  MessageCircle,
  ArrowUpRight,
  ArrowDownLeft,
  Receipt,
} from "lucide-react"
import { PaymentsSection } from "@/components/payments-section"
import { ReceiptUpload } from "@/components/receipt-upload"
import { Analytics } from "@/components/analytics"
import { Rewards } from "@/components/rewards"
import { BillReminders } from "@/components/bill-reminders"
import { Offers } from "@/components/offers"
import { ChatBot } from "@/components/chat-bot"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { SendMoneyContent } from "@/components/send-money-content"
import { ReceiveMoneyContent } from "@/components/receive-money-content"

export default function Dashboard() {
  const [user, setUser] = useState<any>(null)
  const [showBot, setShowBot] = useState(false)
  const [showSendModal, setShowSendModal] = useState(false)
  const [showReceiveModal, setShowReceiveModal] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }
    setUser(JSON.parse(userData))
  }, [router])

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Hello, {user.name}! 👋</h1>
                <p className="text-sm text-gray-500">Welcome back to Google Wallet</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => {
                localStorage.removeItem("user")
                router.push("/")
              }}
            >
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Quick Actions */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  className="w-full justify-start bg-transparent"
                  variant="outline"
                  onClick={() => setShowSendModal(true)}
                >
                  <ArrowUpRight className="w-4 h-4 mr-2" />
                  Send Money
                </Button>
                <Button
                  className="w-full justify-start bg-transparent"
                  variant="outline"
                  onClick={() => setShowReceiveModal(true)}
                >
                  <ArrowDownLeft className="w-4 h-4 mr-2" />
                  Request Money
                </Button>
                <Button className="w-full justify-start bg-transparent" variant="outline">
                  <Receipt className="w-4 h-4 mr-2" />
                  Scan QR Code
                </Button>
                <Button className="w-full justify-start bg-transparent" variant="outline">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Add Card
                </Button>
              </CardContent>
            </Card>

            {/* GPay Icon */}
            <Card className="mt-4">
              <CardContent className="p-4">
                <Button
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  onClick={() => {
                    /* Show recent payments modal */
                  }}
                >
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                      <span className="text-xs font-bold text-blue-600">G</span>
                    </div>
                    <span>Google Pay</span>
                  </div>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="payments" className="space-y-6">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="payments" className="flex items-center space-x-1">
                  <CreditCard className="w-4 h-4" />
                  <span className="hidden sm:inline">Payments</span>
                </TabsTrigger>
                <TabsTrigger value="upload" className="flex items-center space-x-1">
                  <Upload className="w-4 h-4" />
                  <span className="hidden sm:inline">Upload</span>
                </TabsTrigger>
                <TabsTrigger value="analytics" className="flex items-center space-x-1">
                  <BarChart3 className="w-4 h-4" />
                  <span className="hidden sm:inline">Analytics</span>
                </TabsTrigger>
                <TabsTrigger value="rewards" className="flex items-center space-x-1">
                  <Gift className="w-4 h-4" />
                  <span className="hidden sm:inline">Rewards</span>
                </TabsTrigger>
                <TabsTrigger value="bills" className="flex items-center space-x-1">
                  <Bell className="w-4 h-4" />
                  <span className="hidden sm:inline">Bills</span>
                </TabsTrigger>
                <TabsTrigger value="offers" className="flex items-center space-x-1">
                  <MapPin className="w-4 h-4" />
                  <span className="hidden sm:inline">Offers</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="payments">
                <PaymentsSection />
              </TabsContent>

              <TabsContent value="upload">
                <ReceiptUpload />
              </TabsContent>

              <TabsContent value="analytics">
                <Analytics />
              </TabsContent>

              <TabsContent value="rewards">
                <Rewards />
              </TabsContent>

              <TabsContent value="bills">
                <BillReminders />
              </TabsContent>

              <TabsContent value="offers">
                <Offers />
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Send Money Modal */}
        <Dialog open={showSendModal} onOpenChange={setShowSendModal}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <ArrowUpRight className="w-5 h-5 text-red-500" />
                <span>Send Money</span>
              </DialogTitle>
            </DialogHeader>
            <SendMoneyContent />
          </DialogContent>
        </Dialog>

        {/* Receive Money Modal */}
        <Dialog open={showReceiveModal} onOpenChange={setShowReceiveModal}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <ArrowDownLeft className="w-5 h-5 text-green-500" />
                <span>Receive Money</span>
              </DialogTitle>
            </DialogHeader>
            <ReceiveMoneyContent />
          </DialogContent>
        </Dialog>

        {/* Auraya Bot Section */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C13.1 2 14 2.9 14 4C14 5.1 13.1 6 12 6C10.9 6 10 5.1 10 4C10 2.9 10.9 2 12 2ZM21 9V7L15 1H5C3.89 1 3 1.89 3 3V19C3 20.1 3.9 21 5 21H11V19H5V3H13V9H21ZM14 10V12H16V10H14ZM16 13H14V15H16V13ZM20.5 18.08L19.42 19.15L18 17.73V15H16.5V18.27L18.92 20.69L20.5 19.11V18.08Z" />
                  </svg>
                </div>
                <span>Auraya - Your Finance Assistant</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 mb-2">
                    Get instant help with your finances, spending insights, and more!
                  </p>
                  <p className="text-sm text-gray-500">
                    Ask me about payments, bills, rewards, or any financial questions.
                  </p>
                </div>
                <Button
                  onClick={() => setShowBot(!showBot)}
                  className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat with Auraya
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat Bot Modal */}
        {showBot && <ChatBot onClose={() => setShowBot(false)} />}
      </main>
    </div>
  )
}

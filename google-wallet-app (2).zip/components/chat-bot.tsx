"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { X, Send, TrendingUp, CreditCard, Gift, Bell } from "lucide-react"

interface Message {
  id: number
  text: string
  sender: "user" | "bot"
  timestamp: Date
}

interface ChatBotProps {
  onClose: () => void
}

export function ChatBot({ onClose }: ChatBotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi! I'm Auraya, your personal finance assistant. I can help you with spending insights, bill reminders, rewards tracking, and financial advice. How can I assist you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ])
  const [inputMessage, setInputMessage] = useState("")

  const quickReplies = [
    { text: "Show spending summary", icon: TrendingUp },
    { text: "Check bill reminders", icon: Bell },
    { text: "Find nearby offers", icon: CreditCard },
    { text: "Track my rewards", icon: Gift },
  ]

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputMessage,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")

    // Simulate bot response
    setTimeout(() => {
      const botResponse: Message = {
        id: messages.length + 2,
        text: getBotResponse(inputMessage),
        sender: "bot",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, botResponse])
    }, 1000)
  }

  const getBotResponse = (userInput: string): string => {
    const input = userInput.toLowerCase()

    if (input.includes("spending") || input.includes("summary")) {
      return "📊 Your spending summary for July:\n\n• Total spent: ₹7,200\n• Transactions: 22\n• Average per transaction: ₹327\n• Top category: Food & Dining (35%)\n\nYou're spending 12% more than last month. Would you like tips to optimize your expenses?"
    } else if (input.includes("bill") || input.includes("reminder")) {
      return "🔔 Upcoming bills alert:\n\n• Electricity Bill: ₹2,450 (Due in 3 days)\n• Mobile Bill: ₹599 (Due in 6 days)\n• Internet Bill: ₹999 (Due in 10 days)\n• Credit Card: ₹15,750 (Due in 13 days)\n\nTotal pending: ₹19,798. Would you like me to set payment reminders?"
    } else if (input.includes("offer") || input.includes("deal")) {
      return "🎯 Great offers near you:\n\n• Zara: 20% off fashion (0.5km away)\n• Starbucks: Buy 1 Get 1 Free (1.2km)\n• Big Bazaar: ₹100 off groceries (2.1km)\n\nBased on your shopping history, I recommend the Zara offer - you shop there frequently!"
    } else if (input.includes("reward") || input.includes("point")) {
      return "🎁 Your rewards status:\n\n• Total points: 1,250\n• This month: +195 points\n• Recent achievement: July Savings Champion! (₹500 saved)\n\nYou can redeem:\n• 500 points → ₹10 cashback\n• 1000 points → ₹25 cashback\n\nShall I help you redeem points?"
    } else if (input.includes("save") || input.includes("budget")) {
      return "💰 Smart saving tips for you:\n\n• You spend most on Food & Dining (35%)\n• Try cooking at home 2-3 times a week\n• Use offers at your favorite stores\n• Set a monthly budget of ₹6,500\n\nThis could save you ₹700/month! Want me to set up budget alerts?"
    } else if (input.includes("hello") || input.includes("hi")) {
      return "Hello! 👋 I'm here to help you manage your finances better. I can provide insights about your spending, remind you about bills, find great offers, and help you save money. What would you like to know?"
    } else {
      return "I'm here to help with your finances! I can assist with:\n\n💳 Spending analysis & budgeting\n📊 Transaction insights\n🔔 Bill reminders & payments\n🎁 Rewards & cashback tracking\n🎯 Personalized offers\n💡 Financial tips & advice\n\nWhat specific area would you like help with?"
    }
  }

  const handleQuickReply = (reply: string) => {
    setInputMessage(reply)
    setTimeout(() => handleSendMessage(), 100)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl h-[600px] shadow-2xl">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 border-b">
          <CardTitle className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
              <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.1 2 14 2.9 14 4C14 5.1 13.1 6 12 6C10.9 6 10 5.1 10 4C10 2.9 10.9 2 12 2ZM21 9V7L15 1H5C3.89 1 3 1.89 3 3V19C3 20.1 3.9 21 5 21H11V19H5V3H13V9H21ZM14 10V12H16V10H14ZM16 13H14V15H16V13ZM20.5 18.08L19.42 19.15L18 17.73V15H16.5V18.27L18.92 20.69L20.5 19.11V18.08Z" />
              </svg>
            </div>
            <div>
              <span className="text-xl font-bold">Auraya</span>
              <p className="text-sm text-gray-500 font-normal">Your Personal Finance Assistant</p>
            </div>
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose} className="hover:bg-gray-100">
            <X className="w-5 h-5" />
          </Button>
        </CardHeader>

        <CardContent className="p-0 flex flex-col h-[500px]">
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div className="flex items-start space-x-3 max-w-[80%]">
                    {message.sender === "bot" && (
                      <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2C13.1 2 14 2.9 14 4C14 5.1 13.1 6 12 6C10.9 6 10 5.1 10 4C10 2.9 10.9 2 12 2ZM21 9V7L15 1H5C3.89 1 3 1.89 3 3V19C3 20.1 3.9 21 5 21H11V19H5V3H13V9H21Z" />
                        </svg>
                      </div>
                    )}
                    <div
                      className={`p-4 rounded-2xl ${
                        message.sender === "user"
                          ? "bg-blue-600 text-white rounded-br-md"
                          : "bg-gray-100 text-gray-900 rounded-bl-md"
                      }`}
                    >
                      <p className="text-sm whitespace-pre-line leading-relaxed">{message.text}</p>
                      <p className={`text-xs mt-2 ${message.sender === "user" ? "text-blue-100" : "text-gray-500"}`}>
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Quick Replies */}
          <div className="p-4 border-t bg-gray-50">
            <p className="text-sm text-gray-600 mb-3 font-medium">Quick Actions:</p>
            <div className="grid grid-cols-2 gap-2">
              {quickReplies.map((reply, index) => {
                const Icon = reply.icon
                return (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="justify-start bg-white hover:bg-gray-100 text-left h-auto py-2"
                    onClick={() => handleQuickReply(reply.text)}
                  >
                    <Icon className="w-4 h-4 mr-2 text-gray-600" />
                    <span className="text-sm">{reply.text}</span>
                  </Button>
                )
              })}
            </div>
          </div>

          {/* Input */}
          <div className="p-4 border-t">
            <div className="flex space-x-3">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask me anything about your finances..."
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                className="flex-1 rounded-full border-gray-300 focus:border-blue-500"
              />
              <Button
                onClick={handleSendMessage}
                className="rounded-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 px-6"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

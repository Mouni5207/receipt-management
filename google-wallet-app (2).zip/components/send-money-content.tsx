"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Phone, Mail } from "lucide-react"

const recentContacts = [
  { id: 1, name: "John Doe", phone: "+91 98765 43210", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 2, name: "Jane Smith", phone: "+91 87654 32109", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 3, name: "Mike Johnson", phone: "+91 76543 21098", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 4, name: "Sarah Wilson", phone: "+91 65432 10987", avatar: "/placeholder.svg?height=40&width=40" },
]

export function SendMoneyContent() {
  const [sendAmount, setSendAmount] = useState("")
  const [selectedContact, setSelectedContact] = useState<any>(null)

  return (
    <div className="space-y-4">
      <Tabs defaultValue="contacts" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="contacts">Contacts</TabsTrigger>
          <TabsTrigger value="phone">Phone</TabsTrigger>
          <TabsTrigger value="upi">UPI ID</TabsTrigger>
        </TabsList>

        <TabsContent value="contacts" className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="send-amount">Amount</Label>
            <Input
              id="send-amount"
              type="number"
              placeholder="Enter amount"
              value={sendAmount}
              onChange={(e) => setSendAmount(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            <Label>Recent Contacts</Label>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
              {recentContacts.map((contact) => (
                <div
                  key={contact.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedContact?.id === contact.id ? "bg-blue-50 border-blue-200" : "hover:bg-gray-50"
                  }`}
                  onClick={() => setSelectedContact(contact)}
                >
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={contact.avatar || "/placeholder.svg"} />
                      <AvatarFallback>
                        {contact.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{contact.name}</p>
                      <p className="text-sm text-gray-500">{contact.phone}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Button className="w-full" disabled={!sendAmount || !selectedContact}>
            Send ₹{sendAmount || "0"}
          </Button>
        </TabsContent>

        <TabsContent value="phone" className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phone-amount">Amount</Label>
            <Input
              id="phone-amount"
              type="number"
              placeholder="Enter amount"
              value={sendAmount}
              onChange={(e) => setSendAmount(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone-number">Phone Number</Label>
            <Input id="phone-number" type="tel" placeholder="+91 XXXXX XXXXX" />
          </div>
          <Button className="w-full">
            <Phone className="w-4 h-4 mr-2" />
            Send Money
          </Button>
        </TabsContent>

        <TabsContent value="upi" className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="upi-amount">Amount</Label>
            <Input
              id="upi-amount"
              type="number"
              placeholder="Enter amount"
              value={sendAmount}
              onChange={(e) => setSendAmount(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="upi-id">UPI ID</Label>
            <Input id="upi-id" placeholder="example@paytm" />
          </div>
          <Button className="w-full">
            <Mail className="w-4 h-4 mr-2" />
            Send Money
          </Button>
        </TabsContent>
      </Tabs>
    </div>
  )
}

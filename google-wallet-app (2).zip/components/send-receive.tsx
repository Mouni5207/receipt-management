"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowUpRight, ArrowDownLeft, QrCode, Phone, Mail } from "lucide-react"

const recentContacts = [
  { id: 1, name: "John Doe", phone: "+91 98765 43210", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 2, name: "Jane Smith", phone: "+91 87654 32109", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 3, name: "Mike Johnson", phone: "+91 76543 21098", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 4, name: "Sarah Wilson", phone: "+91 65432 10987", avatar: "/placeholder.svg?height=40&width=40" },
]

export function SendReceive() {
  const [sendAmount, setSendAmount] = useState("")
  const [receiveAmount, setReceiveAmount] = useState("")
  const [selectedContact, setSelectedContact] = useState<any>(null)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Send Money */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ArrowUpRight className="w-5 h-5 text-red-500" />
            <span>Send Money</span>
          </CardTitle>
          <CardDescription>Transfer money to friends and family</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="contacts" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="contacts">Contacts</TabsTrigger>
              <TabsTrigger value="phone">Phone</TabsTrigger>
              <TabsTrigger value="upi">UPI ID</TabsTrigger>
            </TabsList>

            <TabsContent value="contacts" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="send-amount">Amount</Label>
                <Input
                  id="send-amount"
                  type="number"
                  placeholder="Enter amount"
                  value={sendAmount}
                  onChange={(e) => setSendAmount(e.target.value)}
                />
              </div>

              <div className="space-y-3">
                <Label>Recent Contacts</Label>
                <div className="grid grid-cols-2 gap-2">
                  {recentContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        selectedContact?.id === contact.id ? "bg-blue-50 border-blue-200" : "hover:bg-gray-50"
                      }`}
                      onClick={() => setSelectedContact(contact)}
                    >
                      <div className="flex items-center space-x-2">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={contact.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {contact.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{contact.name}</p>
                          <p className="text-xs text-gray-500">{contact.phone}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Button className="w-full" disabled={!sendAmount || !selectedContact}>
                Send ₹{sendAmount || "0"}
              </Button>
            </TabsContent>

            <TabsContent value="phone" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone-amount">Amount</Label>
                <Input
                  id="phone-amount"
                  type="number"
                  placeholder="Enter amount"
                  value={sendAmount}
                  onChange={(e) => setSendAmount(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone-number">Phone Number</Label>
                <Input id="phone-number" type="tel" placeholder="+91 XXXXX XXXXX" />
              </div>
              <Button className="w-full">
                <Phone className="w-4 h-4 mr-2" />
                Send Money
              </Button>
            </TabsContent>

            <TabsContent value="upi" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="upi-amount">Amount</Label>
                <Input
                  id="upi-amount"
                  type="number"
                  placeholder="Enter amount"
                  value={sendAmount}
                  onChange={(e) => setSendAmount(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="upi-id">UPI ID</Label>
                <Input id="upi-id" placeholder="example@paytm" />
              </div>
              <Button className="w-full">
                <Mail className="w-4 h-4 mr-2" />
                Send Money
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Receive Money */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ArrowDownLeft className="w-5 h-5 text-green-500" />
            <span>Receive Money</span>
          </CardTitle>
          <CardDescription>Request money or share your payment details</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="request" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="request">Request</TabsTrigger>
              <TabsTrigger value="qr">QR Code</TabsTrigger>
            </TabsList>

            <TabsContent value="request" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="request-amount">Amount</Label>
                <Input
                  id="request-amount"
                  type="number"
                  placeholder="Enter amount"
                  value={receiveAmount}
                  onChange={(e) => setReceiveAmount(e.target.value)}
                />
              </div>

              <div className="space-y-3">
                <Label>Send Request To</Label>
                <div className="grid grid-cols-2 gap-2">
                  {recentContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center space-x-2">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={contact.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {contact.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{contact.name}</p>
                          <p className="text-xs text-gray-500">{contact.phone}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Button className="w-full" disabled={!receiveAmount}>
                Request ₹{receiveAmount || "0"}
              </Button>
            </TabsContent>

            <TabsContent value="qr" className="space-y-4">
              <div className="text-center space-y-4">
                <div className="w-48 h-48 bg-gray-100 rounded-lg flex items-center justify-center mx-auto">
                  <QrCode className="w-24 h-24 text-gray-400" />
                </div>
                <div>
                  <h3 className="font-semibold">Your Payment QR Code</h3>
                  <p className="text-sm text-gray-500">Share this QR code to receive payments</p>
                </div>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full bg-transparent">
                    Share QR Code
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    Download QR Code
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

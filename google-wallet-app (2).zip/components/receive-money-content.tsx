"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { QrCode } from "lucide-react"

const recentContacts = [
  { id: 1, name: "John Doe", phone: "+91 98765 43210", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 2, name: "Jane Smith", phone: "+91 87654 32109", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 3, name: "Mike Johnson", phone: "+91 76543 21098", avatar: "/placeholder.svg?height=40&width=40" },
  { id: 4, name: "Sarah Wilson", phone: "+91 65432 10987", avatar: "/placeholder.svg?height=40&width=40" },
]

export function ReceiveMoneyContent() {
  const [receiveAmount, setReceiveAmount] = useState("")

  return (
    <div className="space-y-4">
      <Tabs defaultValue="request" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="request">Request</TabsTrigger>
          <TabsTrigger value="qr">QR Code</TabsTrigger>
        </TabsList>

        <TabsContent value="request" className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="request-amount">Amount</Label>
            <Input
              id="request-amount"
              type="number"
              placeholder="Enter amount"
              value={receiveAmount}
              onChange={(e) => setReceiveAmount(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            <Label>Send Request To</Label>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
              {recentContacts.map((contact) => (
                <div
                  key={contact.id}
                  className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={contact.avatar || "/placeholder.svg"} />
                      <AvatarFallback>
                        {contact.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{contact.name}</p>
                      <p className="text-sm text-gray-500">{contact.phone}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Button className="w-full" disabled={!receiveAmount}>
            Request ₹{receiveAmount || "0"}
          </Button>
        </TabsContent>

        <TabsContent value="qr" className="space-y-4">
          <div className="text-center space-y-4">
            <div className="w-40 h-40 bg-gray-100 rounded-lg flex items-center justify-center mx-auto">
              <QrCode className="w-20 h-20 text-gray-400" />
            </div>
            <div>
              <h3 className="font-semibold">Your Payment QR Code</h3>
              <p className="text-sm text-gray-500">Share this QR code to receive payments</p>
            </div>
            <div className="space-y-2">
              <Button variant="outline" className="w-full bg-transparent">
                Share QR Code
              </Button>
              <Button variant="outline" className="w-full bg-transparent">
                Download QR Code
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

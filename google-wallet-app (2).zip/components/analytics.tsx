"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { BarChart, Bar, XAxis, YAxis, PieChart, Pie, Cell, CartesianGrid } from "recharts"
import { TrendingUp, TrendingDown, BarChart3 } from "lucide-react"

const monthlyData = [
  { month: "Jan", amount: 4500, transactions: 12 },
  { month: "Feb", amount: 3200, transactions: 8 },
  { month: "Mar", amount: 5800, transactions: 15 },
  { month: "Apr", amount: 4200, transactions: 11 },
  { month: "May", amount: 6100, transactions: 18 },
  { month: "Jun", amount: 5500, transactions: 14 },
  { month: "Jul", amount: 7200, transactions: 22 },
]

const categoryData = [
  { name: "Food & Dining", value: 35, color: "#8884d8" },
  { name: "Shopping", value: 25, color: "#82ca9d" },
  { name: "Transportation", value: 15, color: "#ffc658" },
  { name: "Entertainment", value: 12, color: "#ff7300" },
  { name: "Bills & Utilities", value: 13, color: "#00ff88" },
]

const shopData = [
  { shop: "Zara", amount: 2850, visits: 3 },
  { shop: "Starbucks", amount: 1350, visits: 8 },
  { shop: "Big Bazaar", amount: 2100, visits: 4 },
  { shop: "McDonald's", amount: 890, visits: 6 },
  { shop: "Reliance Digital", amount: 15000, visits: 1 },
]

export function Analytics() {
  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent This Month</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹7,200</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transactions</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">22</div>
            <p className="text-xs text-muted-foreground">+8 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Transaction</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹327</div>
            <p className="text-xs text-muted-foreground">-5% from last month</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Spending */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Spending Trend</CardTitle>
            <CardDescription>Your spending pattern over the last 7 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                amount: {
                  label: "Amount (₹)",
                  color: "hsl(var(--chart-1))",
                },
              }}
              className="h-[300px] w-full"
            >
              <BarChart
                data={monthlyData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 20,
                }}
                width={500}
                height={300}
              >
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `₹${value}`}
                />
                <ChartTooltip content={<ChartTooltipContent />} formatter={(value) => [`₹${value}`, "Amount"]} />
                <Bar dataKey="amount" fill="var(--color-amount)" radius={[4, 4, 0, 0]} maxBarSize={60} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Category Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Spending by Category</CardTitle>
            <CardDescription>Where your money goes</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                value: {
                  label: "Percentage",
                  color: "hsl(var(--chart-1))",
                },
              }}
              className="h-[300px] w-full"
            >
              <PieChart width={400} height={300}>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} formatter={(value) => [`${value}%`, "Percentage"]} />
              </PieChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Shop Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Top Shops</CardTitle>
          <CardDescription>Your most visited stores and spending</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {shopData.map((shop, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-blue-600">{shop.shop[0]}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">{shop.shop}</h3>
                    <p className="text-sm text-gray-500">{shop.visits} visits</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold">₹{shop.amount}</p>
                  <p className="text-sm text-gray-500">Total spent</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

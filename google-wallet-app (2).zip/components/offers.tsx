"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { MapPin, Percent, Clock, Store, Globe, Navigation } from "lucide-react"

const nearbyOffers = [
  {
    id: 1,
    title: "20% Off on Fashion",
    store: "Zara - Phoenix Mall",
    description: "Get 20% off on all clothing items",
    discount: "20%",
    distance: "0.5 km",
    validUntil: "2024-08-15",
    type: "offline",
  },
  {
    id: 2,
    title: "Buy 1 Get 1 Free",
    store: "Starbucks - Bandra",
    description: "Buy any grande beverage and get another free",
    discount: "50%",
    distance: "1.2 km",
    validUntil: "2024-08-10",
    type: "offline",
  },
  {
    id: 3,
    title: "₹100 Off on Groceries",
    store: "Big Bazaar - Andheri",
    description: "Minimum purchase of ₹500 required",
    discount: "₹100",
    distance: "2.1 km",
    validUntil: "2024-08-20",
    type: "offline",
  },
]

const onlineOffers = [
  {
    id: 1,
    title: "Flat 30% Off",
    store: "Amazon",
    description: "On electronics and gadgets",
    discount: "30%",
    validUntil: "2024-08-25",
    type: "online",
  },
  {
    id: 2,
    title: "Free Delivery",
    store: "Swiggy",
    description: "On orders above ₹199",
    discount: "Free",
    validUntil: "2024-08-12",
    type: "online",
  },
  {
    id: 3,
    title: "Cashback ₹200",
    store: "Flipkart",
    description: "On first purchase using Google Pay",
    discount: "₹200",
    validUntil: "2024-08-30",
    type: "online",
  },
]

export function Offers() {
  const [locationEnabled, setLocationEnabled] = useState(true)
  const [currentLocation, setCurrentLocation] = useState("Bandra West, Mumbai")

  const handleLocationToggle = () => {
    if (!locationEnabled) {
      // Simulate getting location
      setCurrentLocation("Bandra West, Mumbai")
    }
    setLocationEnabled(!locationEnabled)
  }

  return (
    <div className="space-y-6">
      {/* Location Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MapPin className="w-5 h-5" />
            <span>Location Settings</span>
          </CardTitle>
          <CardDescription>Enable location to see nearby offers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="location-toggle">Enable Location Services</Label>
              <p className="text-sm text-gray-500">
                {locationEnabled ? `Current location: ${currentLocation}` : "Location services disabled"}
              </p>
            </div>
            <Switch id="location-toggle" checked={locationEnabled} onCheckedChange={handleLocationToggle} />
          </div>
          {locationEnabled && (
            <Button variant="outline" className="mt-4 bg-transparent" size="sm">
              <Navigation className="w-4 h-4 mr-2" />
              Update Location
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Nearby Offers */}
      {locationEnabled && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Store className="w-5 h-5" />
              <span>Nearby Offers</span>
            </CardTitle>
            <CardDescription>Exclusive deals near your location</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {nearbyOffers.map((offer) => (
                <div key={offer.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {offer.discount} OFF
                    </Badge>
                    <div className="text-right text-xs text-gray-500">
                      <div className="flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        {offer.distance}
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{offer.title}</h3>
                    <p className="text-sm font-medium text-blue-600">{offer.store}</p>
                    <p className="text-sm text-gray-600 mt-1">{offer.description}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-xs text-gray-500">
                      <Clock className="w-3 h-3 mr-1" />
                      Valid until {new Date(offer.validUntil).toLocaleDateString()}
                    </div>
                    <Button size="sm">Claim</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Online Offers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="w-5 h-5" />
            <span>Online Offers</span>
          </CardTitle>
          <CardDescription>Great deals from your favorite online stores</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {onlineOffers.map((offer) => (
              <div key={offer.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                    {offer.discount}
                  </Badge>
                  <Badge variant="outline">Online</Badge>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{offer.title}</h3>
                  <p className="text-sm font-medium text-purple-600">{offer.store}</p>
                  <p className="text-sm text-gray-600 mt-1">{offer.description}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock className="w-3 h-3 mr-1" />
                    Valid until {new Date(offer.validUntil).toLocaleDateString()}
                  </div>
                  <Button size="sm">Shop Now</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Personalized Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Percent className="w-5 h-5" />
            <span>Recommended for You</span>
          </CardTitle>
          <CardDescription>Based on your shopping history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 border rounded-lg bg-gradient-to-r from-purple-50 to-pink-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">Fashion Week Special</h3>
                  <p className="text-sm text-gray-600">Extra 25% off at Zara - your favorite store!</p>
                  <p className="text-xs text-gray-500 mt-1">Based on your recent purchases</p>
                </div>
                <Button>View Offer</Button>
              </div>
            </div>
            <div className="p-4 border rounded-lg bg-gradient-to-r from-green-50 to-blue-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">Coffee Lover's Deal</h3>
                  <p className="text-sm text-gray-600">Get 3 free coffees with Starbucks membership</p>
                  <p className="text-xs text-gray-500 mt-1">You visit coffee shops frequently</p>
                </div>
                <Button>Learn More</Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

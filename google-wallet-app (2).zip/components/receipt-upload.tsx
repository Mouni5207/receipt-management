"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Camera, FileText, PenTool, ImageIcon, File } from "lucide-react"

export function ReceiptUpload() {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [manualReceipt, setManualReceipt] = useState({
    shopName: "",
    amount: "",
    date: "",
    items: "",
  })

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setUploadedFiles((prev) => [...prev, ...files])
  }

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle manual receipt submission
    console.log("Manual receipt:", manualReceipt)
    // Reset form
    setManualReceipt({ shopName: "", amount: "", date: "", items: "" })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Upload className="w-5 h-5" />
            <span>Upload Receipts</span>
          </CardTitle>
          <CardDescription>Add your receipts for better expense tracking</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="upload" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="upload">Upload File</TabsTrigger>
              <TabsTrigger value="camera">Camera</TabsTrigger>
              <TabsTrigger value="manual">Manual Entry</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Upload Receipt</h3>
                <p className="text-gray-500 mb-4">Drag and drop files or click to browse</p>
                <Input
                  type="file"
                  multiple
                  accept="image/*,.pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <Label htmlFor="file-upload">
                  <Button variant="outline" className="cursor-pointer bg-transparent">
                    <File className="w-4 h-4 mr-2" />
                    Choose Files
                  </Button>
                </Label>
              </div>

              {uploadedFiles.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold">Uploaded Files:</h4>
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center space-x-2 p-2 bg-gray-50 rounded">
                      <ImageIcon className="w-4 h-4" />
                      <span className="text-sm">{file.name}</span>
                      <span className="text-xs text-gray-500">({(file.size / 1024).toFixed(1)} KB)</span>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="camera" className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Capture Receipt</h3>
                <p className="text-gray-500 mb-4">Use your camera to scan receipts</p>
                <Button>
                  <Camera className="w-4 h-4 mr-2" />
                  Open Camera
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="manual" className="space-y-4">
              <form onSubmit={handleManualSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="shopName">Shop Name</Label>
                    <Input
                      id="shopName"
                      value={manualReceipt.shopName}
                      onChange={(e) => setManualReceipt((prev) => ({ ...prev, shopName: e.target.value }))}
                      placeholder="Enter shop name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="amount">Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={manualReceipt.amount}
                      onChange={(e) => setManualReceipt((prev) => ({ ...prev, amount: e.target.value }))}
                      placeholder="Enter amount"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={manualReceipt.date}
                    onChange={(e) => setManualReceipt((prev) => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="items">Items</Label>
                  <Textarea
                    id="items"
                    value={manualReceipt.items}
                    onChange={(e) => setManualReceipt((prev) => ({ ...prev, items: e.target.value }))}
                    placeholder="List items purchased (one per line)"
                    rows={4}
                  />
                </div>
                <Button type="submit" className="w-full">
                  <PenTool className="w-4 h-4 mr-2" />
                  Save Receipt
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              <div className="text-center py-8">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No receipts uploaded yet</h3>
                <p className="text-gray-500">Start uploading receipts to see them here</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

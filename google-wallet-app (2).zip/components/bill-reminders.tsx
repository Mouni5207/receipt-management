"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bell, Zap, Wifi, Phone, CreditCard, Calendar } from "lucide-react"

const upcomingBills = [
  {
    id: 1,
    name: "Electricity Bill",
    provider: "MSEB",
    amount: 2450,
    dueDate: "2024-08-05",
    status: "due_soon",
    icon: Zap,
  },
  {
    id: 2,
    name: "Mobile Bill",
    provider: "Airtel",
    amount: 599,
    dueDate: "2024-08-08",
    status: "upcoming",
    icon: Phone,
  },
  {
    id: 3,
    name: "Internet Bill",
    provider: "Jio Fiber",
    amount: 999,
    dueDate: "2024-08-12",
    status: "upcoming",
    icon: Wifi,
  },
  {
    id: 4,
    name: "Credit Card Bill",
    provider: "HDFC Bank",
    amount: 15750,
    dueDate: "2024-08-15",
    status: "upcoming",
    icon: CreditCard,
  },
]

const paidBills = [
  {
    id: 1,
    name: "Gas Bill",
    provider: "Indane Gas",
    amount: 850,
    paidDate: "2024-07-28",
    icon: Zap,
  },
  {
    id: 2,
    name: "Water Bill",
    provider: "BMC",
    amount: 320,
    paidDate: "2024-07-25",
    icon: Zap,
  },
]

export function BillReminders() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "due_soon":
        return "destructive"
      case "upcoming":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const getDaysUntilDue = (dueDate: string) => {
    const today = new Date()
    const due = new Date(dueDate)
    const diffTime = due.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Due</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹19,798</div>
            <p className="text-xs text-muted-foreground">4 bills pending</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Due Soon</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
            <p className="text-xs text-muted-foreground">Within 3 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paid This Month</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹1,170</div>
            <p className="text-xs text-muted-foreground">2 bills paid</p>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Bills */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="w-5 h-5" />
            <span>Upcoming Bills</span>
          </CardTitle>
          <CardDescription>Bills that need your attention</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {upcomingBills.map((bill) => {
              const Icon = bill.icon
              const daysUntilDue = getDaysUntilDue(bill.dueDate)

              return (
                <div key={bill.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{bill.name}</h3>
                      <p className="text-sm text-gray-500">{bill.provider}</p>
                      <p className="text-xs text-gray-500">
                        Due: {new Date(bill.dueDate).toLocaleDateString()}
                        {daysUntilDue <= 3 && <span className="text-red-500 ml-2">({daysUntilDue} days left)</span>}
                      </p>
                    </div>
                  </div>
                  <div className="text-right space-y-2">
                    <p className="font-semibold text-gray-900">₹{bill.amount}</p>
                    <div className="flex space-x-2">
                      <Badge variant={getStatusColor(bill.status)}>
                        {bill.status === "due_soon" ? "Due Soon" : "Upcoming"}
                      </Badge>
                      <Button size="sm">Pay Now</Button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recently Paid */}
      <Card>
        <CardHeader>
          <CardTitle>Recently Paid</CardTitle>
          <CardDescription>Bills you've paid this month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {paidBills.map((bill) => {
              const Icon = bill.icon

              return (
                <div key={bill.id} className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{bill.name}</h3>
                      <p className="text-sm text-gray-500">{bill.provider}</p>
                      <p className="text-xs text-gray-500">Paid: {new Date(bill.paidDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">₹{bill.amount}</p>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Paid
                    </Badge>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Calendar, CreditCard, Receipt } from "lucide-react"

const recentPayments = [
  {
    id: 1,
    shop: "Zara Fashion Store",
    amount: 2850,
    date: "2024-01-15",
    upiId: "zara@paytm",
    items: [
      { name: "Cotton Shirt", price: 1200 },
      { name: "Denim Jeans", price: 1650 },
    ],
    location: "Phoenix Mall, Mumbai",
  },
  {
    id: 2,
    shop: "Starbucks Coffee",
    amount: 450,
    date: "2024-01-14",
    upiId: "starbucks@upi",
    items: [
      { name: "Cappuccino Grande", price: 280 },
      { name: "Blueberry Muffin", price: 170 },
    ],
    location: "Bandra West, Mumbai",
  },
  {
    id: 3,
    shop: "Big Bazaar",
    amount: 1250,
    date: "2024-01-13",
    upiId: "bigbazaar@paytm",
    items: [
      { name: "Groceries", price: 850 },
      { name: "Household Items", price: 400 },
    ],
    location: "Andheri East, Mumbai",
  },
]

export function PaymentsSection() {
  const [selectedPayment, setSelectedPayment] = useState<any>(null)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5" />
            <span>Recent Payments</span>
          </CardTitle>
          <CardDescription>Your latest transactions and purchases</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentPayments.map((payment) => (
              <Dialog key={payment.id}>
                <DialogTrigger asChild>
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Receipt className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{payment.shop}</h3>
                        <p className="text-sm text-gray-500 flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(payment.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">₹{payment.amount}</p>
                      <Badge variant="secondary">Completed</Badge>
                    </div>
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Payment Receipt</DialogTitle>
                    <DialogDescription>Transaction details</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="text-center py-4">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Receipt className="w-8 h-8 text-green-600" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900">{payment.shop}</h3>
                      <p className="text-2xl font-bold text-green-600 mt-2">₹{payment.amount}</p>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Date:</span>
                        <span className="font-medium">{new Date(payment.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">UPI ID:</span>
                        <span className="font-medium">{payment.upiId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Location:</span>
                        <span className="font-medium text-sm">{payment.location}</span>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h4 className="font-semibold mb-3">Items Purchased:</h4>
                      <div className="space-y-2">
                        {payment.items.map((item, index) => (
                          <div key={index} className="flex justify-between">
                            <span className="text-gray-600">{item.name}</span>
                            <span className="font-medium">₹{item.price}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    <div className="flex justify-between font-bold text-lg">
                      <span>Total:</span>
                      <span>₹{payment.amount}</span>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

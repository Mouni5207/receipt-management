"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Gift, Trophy, Star, Zap, Target } from "lucide-react"

const rewards = [
  {
    id: 1,
    title: "July Savings Champion! 🎉",
    description: "Congratulations! You saved ₹500 this July compared to June",
    type: "achievement",
    points: 100,
    date: "2024-07-31",
  },
  {
    id: 2,
    title: "Cashback Earned",
    description: "₹45 cashback from your recent Zara purchase",
    type: "cashback",
    points: 45,
    date: "2024-07-28",
  },
  {
    id: 3,
    title: "Streak Master",
    description: "7 days of tracking expenses! Keep it up!",
    type: "streak",
    points: 50,
    date: "2024-07-25",
  },
]

const challenges = [
  {
    id: 1,
    title: "Spend Smart Challenge",
    description: "Keep your monthly spending under ₹8000",
    progress: 75,
    target: 8000,
    current: 6000,
    reward: 200,
  },
  {
    id: 2,
    title: "Receipt Collector",
    description: "Upload 10 receipts this month",
    progress: 60,
    target: 10,
    current: 6,
    reward: 100,
  },
]

export function Rewards() {
  return (
    <div className="space-y-6">
      {/* Points Summary */}
      <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="w-6 h-6" />
            <span>Your Rewards</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-purple-100">Total Points</p>
              <p className="text-3xl font-bold">1,250</p>
            </div>
            <div>
              <p className="text-purple-100">This Month</p>
              <p className="text-3xl font-bold">195</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Rewards */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Gift className="w-5 h-5" />
            <span>Recent Rewards</span>
          </CardTitle>
          <CardDescription>Your latest achievements and earnings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rewards.map((reward) => (
              <div key={reward.id} className="flex items-start space-x-4 p-4 border rounded-lg">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  {reward.type === "achievement" && <Trophy className="w-6 h-6 text-yellow-600" />}
                  {reward.type === "cashback" && <Star className="w-6 h-6 text-yellow-600" />}
                  {reward.type === "streak" && <Zap className="w-6 h-6 text-yellow-600" />}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{reward.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{reward.description}</p>
                  <p className="text-xs text-gray-500 mt-2">{new Date(reward.date).toLocaleDateString()}</p>
                </div>
                <Badge variant="secondary">+{reward.points} pts</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Challenges */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="w-5 h-5" />
            <span>Active Challenges</span>
          </CardTitle>
          <CardDescription>Complete challenges to earn more rewards</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {challenges.map((challenge) => (
              <div key={challenge.id} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{challenge.title}</h3>
                    <p className="text-sm text-gray-600">{challenge.description}</p>
                  </div>
                  <Badge variant="outline">+{challenge.reward} pts</Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>
                      Progress: {challenge.current}/{challenge.target}
                    </span>
                    <span>{challenge.progress}%</span>
                  </div>
                  <Progress value={challenge.progress} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Redeem Points */}
      <Card>
        <CardHeader>
          <CardTitle>Redeem Points</CardTitle>
          <CardDescription>Use your points for exciting rewards</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold">₹10 Cashback</h3>
              <p className="text-sm text-gray-600">Minimum 500 points required</p>
              <Button className="w-full mt-3" disabled={1250 < 500}>
                Redeem (500 pts)
              </Button>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold">₹25 Cashback</h3>
              <p className="text-sm text-gray-600">Minimum 1000 points required</p>
              <Button className="w-full mt-3" disabled={1250 < 1000}>
                Redeem (1000 pts)
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
